"""
-------------------------------------------------------
Assignment 2, Task 2
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
num = int(input("Enter a positive digit number:"))
first = num//10
second = num % 10
answer = first-second
print(f"The difference of the digits of {num} is {answer}")
