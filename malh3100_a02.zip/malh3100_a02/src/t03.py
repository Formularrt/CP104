"""
-------------------------------------------------------
Assignment 2, Task 3
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-07"
-------------------------------------------------------
"""


text = int(input("Enter a date in the format YYYYMMDD:"))

year = text // 10000
month = text % 10000 // 100
day = text % 100

print(f"The reformatted date: {year}/{month}/{day}")
