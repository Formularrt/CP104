"""
-------------------------------------------------------
Assignment 2, Task 4
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""

flyers = int(input("Number of flyers:"))
delivery = int(input("Number of delivery people:"))

fpdp = flyers//delivery
# fpdp = flyers per delivery person
remainder = flyers % delivery

print(f"""
Flyers per delivery person: {fpdp}
Flyers left over: {remainder}
""")
