"""
-------------------------------------------------------
Assignment 2, Task 5
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-07"
-------------------------------------------------------
"""
length = float(input("Foundation length (m): "))
width = float(input("Foundation width (m): "))
height = float(input("Foundation height (m): "))
wall_height = float(input("Wall height (m): "))
price_concrete = float(input("Cost of concrete ($/m^3): "))
price_brick = float(input("Cost of bricks ($/m^2): "))

foundation = length * width * height
concrete = foundation * price_concrete
brick = (2 * (wall_height * length) + 2 * (wall_height * width))
cost = brick * price_brick
total = cost + concrete

print()
print(f"Concrete needed for foundation (m^3): {foundation:.2f}")
print(f"Cost of concrete ${concrete:.2f}")
print(f"Bricks needed for walls (m^2): {brick:.2f}")
print(f"Cost of bricks: ${cost:.2f}")
print(f"Total cost: ${total:.2f}")
