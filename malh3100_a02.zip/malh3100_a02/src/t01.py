"""
-------------------------------------------------------
Assignment 2, Task 1
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
# Constant
ANNUALTAX = 0.185

sales = float(input("Enter the total sales: "))

tax = sales*ANNUALTAX

print(f"""
Projected Tax Report
--------------------------
Total sales:   $ {sales}
Annual tax:    % {ANNUALTAX*100}
--------------------------
Tax:           $  {tax}
""")
