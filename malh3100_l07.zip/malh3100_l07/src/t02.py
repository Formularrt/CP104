"""
-------------------------------------------------------
Lab 7 task 2
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""

from functions import power_of_two

power = power_of_two(3)
print(power)
power = power_of_two(4)
print(power)
power = power_of_two(248)
print(power)
