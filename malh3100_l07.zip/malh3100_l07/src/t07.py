"""
-------------------------------------------------------
Lab 7 task 7
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
from functions import meal_costs

meal_costs()
