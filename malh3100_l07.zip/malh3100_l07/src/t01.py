
from functions import hi_lo_game

count = hi_lo_game(100)

print(f"{count}")
