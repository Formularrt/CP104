"""
-------------------------------------------------------
Lab 7 task 10
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""

from functions import employee_payroll

total, average = employee_payroll()

print(total, average)
