"""
-------------------------------------------------------
Assignment 08 Task 04
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
from functions import valid_isbn
isbn_num = str(input("Input a isbn: "))
valid = valid_isbn(isbn_num)

print(valid)
