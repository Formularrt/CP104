"""
-------------------------------------------------------
Assignment 08 Task 03
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-14"
-------------------------------------------------------
"""
from functions import common_end

print(common_end('ing', 'jumping'))
