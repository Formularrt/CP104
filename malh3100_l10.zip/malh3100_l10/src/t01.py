"""
-------------------------------------------------------
Lab 10 task 1
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
from functions import customer_record

fh = open("customers.txt", "r")

n = int(input("Enter record number: "))

result = customer_record(fh, n)

fh.close()

print(result)
