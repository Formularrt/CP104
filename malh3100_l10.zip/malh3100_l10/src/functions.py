"""
-------------------------------------------------------
Functions Library
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# task 1


def customer_record(fh, n):
    """
    -------------------------------------------------------
    Find the n-th record in a comma-delimited sequential file.
    Records are numbered starting with 0.
    Use: result = customer_record(fh, n)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
        n - the number of the record to return (int > 0)
    Returns:
        result - a list of the fields of the n-th record if it exists,
            an empty list otherwise (list)
    -------------------------------------------------------
    """
    result = []
    i = 0
    line = fh.readline()

    while line != "" and i < n:
        i += 1
        line = fh.readline()

    if line != "":
        result = line.strip().split(",")

    return result

# task 03


def customer_best(fh):
    """
    -------------------------------------------------------
    Find the customer with the largest balance.
    Assumes file is not empty.
    Use: result = customer_best(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        result - the record with the greatest balance (list)
    -------------------------------------------------------
    """
    result = []  # Initialize an empty list to store the record with the greatest balance
    # Initialize the maximum balance to negative infinity
    max_balance = float('-inf')

    for line in fh:
        # Split the line into a list using comma as the delimiter
        customer_data = line.strip().split(",")

        # Extract the balance from the customer_data
        balance = float(customer_data[3])  # Assuming balance is at index 3

        # Check if the current balance is greater than the maximum balance
        if balance > max_balance:
            max_balance = balance
            result = customer_data

    return result
# task 7


def append_max_num(fh):
    """
    -------------------------------------------------------
    Appends a number to the end of fh. The number appended
    is the maximum of all the numbers currently in the file.
    Assumes file is not empty.
    Use: num = append_max_num(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading/writing)
    Returns:
        num - the number appended to the file (int)
    ------------------------------------------------------
    """
    num = 0

    for lines in fh:
        if int(lines.strip()) > num:
            num = int(lines.strip())

    fh.write(f"\n{num:d}")
    return num
# task 11


def find_longest(fh):
    """
    -------------------------------------------------------
    Finds the last word with longest length in fh.
    Assumes file is not empty.
    Use: word = find_longest(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        word - the last word with the longest length in fh (str)
    ------------------------------------------------------
    """
    line1 = fh.readline()
    word = line1.strip()
    largest = len(word)
    for line in fh:
        if largest <= len(line.strip()):
            word = line.strip()
            largest = len(word)

    return word

# task 13


def file_copy(fh_1, fh_2):
    """
    -------------------------------------------------------
    Copies the contents of fh_1 to fh_2.
    Any contents of fh_2 are overwritten.
    Use: file_copy(fh_1, fh_2)
    -------------------------------------------------------
    Parameters:
        fh_1 - source file (file handle - already open for reading)
        fh_2 - target file (file handle - already open for writing)
    Returns:
        None
    ------------------------------------------------------
    """
    line = fh_1.readline()

    while line != "":

        fh_2.write(line)
        line = fh_1.readline()

    return
