from functions import customer_best
file_path = 'customers.txt'

fh = open("customers.txt", "r")
result = customer_best(fh)

fh.close()

print(result)
