from functions import append_max_num
filename = "numbers.txt"
fh = open(filename, "r+")

result = append_max_num(fh)
fh.close()

print(f"{result} is appended")
