from functions import find_longest
filename = "words.txt"
fh = open(filename, "r+")
result = find_longest(fh)
fh.close()

print(f"'{result}' is the last longest word")
