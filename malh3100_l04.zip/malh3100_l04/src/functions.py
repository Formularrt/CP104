"""
-------------------------------------------------------
Functions Library
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
import math


def diameter(radius):
    """
    -------------------------------------------------------
    Calculates and returns diameter of a circle.
    Use: diam = diameter(radius)
    -------------------------------------------------------
    Parameters:
        radius - radius of a circle (float >= 0)
    Returns:
        diam - diameter of a circle (float)
    ------------------------------------------------------
    """
    if radius < 0:
        raise ValueError("Radius must be a non-negative number.")

    diam = 2 * radius
    return diam


def square_pyramid(base, height):
    """
    -------------------------------------------------------
    Calculates and returns the slant height, area, and
    volume of a square pyramid given the base and perpendicular
    height.
    Use: sh, area, vol = square_pyramid(base, height)
    -------------------------------------------------------
    Parameters:
        base - length of the base of the pyramid (float > 0)
        height - perpendicular height of the pyramid (float > 0)
    Returns:
        sh - slant height of the square pyramid (float)
        area - area of the square pyramid (float)
        vol - volume of the square pyramid (float)
    ------------------------------------------------------
    """
    if base <= 0 or height <= 0:
        raise ValueError("Base and height must be positive numbers.")

    # Calculate the slant height
    sh = math.sqrt(base**2 + height**2)

    # Calculate the surface area
    area = base**2 + 2 * base * sh

    # Calculate the volume
    vol = (1/3) * base**2 * height

    return sh, area, vol


def pythag(s1, s2):
    """
    Calculates and returns the radius, diameter, circumference,
    and area of a circle defined by a right triangle.

    Parameters:
        s1 - length of side 1 of a right triangle (float > 0)
        s2 - length of side 2 of a right triangle (float > 0)

    Returns:
        radius - radius of the resulting circle (float)
        diam - diameter of the resulting circle (float)
        circ - circumference of the resulting circle (float)
        area - area of the resulting circle (float)
    """
    if s1 <= 0 or s2 <= 0:
        raise ValueError("Side lengths must be positive numbers.")

    # Calculate the hypotenuse
    hypotenuse = math.sqrt(s1**2 + s2**2)

    # Calculate the radius
    radius = hypotenuse / 2

    # Calculate the diameter
    diam = 2 * radius

    # Calculate the circumference
    circ = 2 * math.pi * radius

    # Calculate the area
    area = math.pi * radius**2

    return radius, diam, circ, area


def population(size, births, deaths, immigrants, years):
    """
    Calculates future population given various factors.

    Parameters:
       size - current population (int >= 0)
       births - average seconds between births (int >= 0)
       deaths - average seconds between deaths (int >= 0)
       immigrants - average seconds between immigrations (int >= 0)
       years - years to calculate new population (int > 0)

    Returns:
       new_size - new population size (int)
    """
    # Constants for the number of seconds in a year
    SECONDS_PER_YEAR = 31536000

    births_per_year = SECONDS_PER_YEAR/births
    deaths_per_year = SECONDS_PER_YEAR/deaths
    immigrants_per_year = SECONDS_PER_YEAR/immigrants

    new_size = size

    new_size = new_size + \
        (years * (births_per_year - deaths_per_year + immigrants_per_year))

    return int(new_size)


def f_to_c(fahrenheit):
    """
    Converts temperatures in Fahrenheit to Celsius.

    Parameters:
        fahrenheit - temperature in Fahrenheit (int >= -459)

    Returns:
        celsius - equivalent temperature in Celsius (float)
    """
    if fahrenheit < -459:
        raise ValueError(
            "Temperature in Fahrenheit cannot be lower than -459 (absolute zero).")

    celsius = (fahrenheit - 32) * 5/9
    return celsius
