
"""
-------------------------------------------------------
Lab 3, Task 10 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""

from functions import population

size = int(input("Enter the current population: "))
births = int(input("Enter the average seconds between births: "))
deaths = int(input("Enter the average seconds between deaths: "))
immigrants = int(input("Enter the average seconds between immigrations: "))
years = int(input("Enter the number of years to calculate new population: "))

new_size = population(size, births, deaths, immigrants, years)

print(f"{new_size}")
