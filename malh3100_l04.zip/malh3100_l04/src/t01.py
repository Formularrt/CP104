"""
-------------------------------------------------------
Lab 3, Task 1 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
from functions import diameter

# Test the diameter function
radius = float(input("Enter the radius: "))
diam = diameter(radius)
print(diam)
