"""
-------------------------------------------------------
Lab 3, Task 4 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""

from functions import square_pyramid

# Test the square_pyramid function
base = float(input("Enter the base:"))
height = float(input("Enter the height:"))
sh, area, vol = square_pyramid(base, height)

print("Slant Height:", sh)
print("Area:", area)
print("Volume:", vol)
