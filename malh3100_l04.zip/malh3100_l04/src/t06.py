"""
-------------------------------------------------------
Lab 3, Task 6 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""

from functions import pythag

# Test the pythag function
s1 = float(input("Input side 1: "))
s2 = float(input("Input side 2: "))
radius, diam, circ, area = pythag(s1, s2)

print("Hypotenuse:", s1)
print("Radius:", radius)
print("Diameter:", diam)
print("Circumference:", circ)
print("Area:", area)
