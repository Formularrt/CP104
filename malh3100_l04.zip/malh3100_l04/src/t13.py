"""
-------------------------------------------------------
Lab 3, Task 13 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""

from functions import f_to_c

# Test the f_to_c function
fahrenheit = float(input("Enter fahrenheit: "))
celsius = f_to_c(fahrenheit)

print(celsius)
