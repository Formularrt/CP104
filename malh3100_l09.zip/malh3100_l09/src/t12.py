"""
-------------------------------------------------------
Lab 9 task 12
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-14"
-------------------------------------------------------
"""
from functions import comma_period_replace

print(comma_period_replace('Number 1, Number 2, Number 3,'))
