"""
-------------------------------------------------------
Lab 9 task 10
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-14"
-------------------------------------------------------
"""
from functions import text_analyze

print(text_analyze("HilloHOBOhoho676 66                               "))
