"""
-------------------------------------------------------
Lab 11 task 14
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-30"
-------------------------------------------------------
"""
from functions import matrix_transpose

print(matrix_transpose([[6, 4, 24], [1, -9, 8]]))
