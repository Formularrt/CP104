"""
-------------------------------------------------------
Functions Library
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-30"
-------------------------------------------------------
"""

import random
# task 1


def generate_matrix_num(rows, cols, low, high, value_type):
    """
    -------------------------------------------------------
    Generates a 2D list of numbers of the given type, 'float' or 'int'.
    (To generate random float number use random.uniform and to
    generate random integer number use random.randint)
    Use: matrix = generate_matrix_num(rows, cols, low, high, value_type)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the list (int > 0)
        cols - number of columns (int > 0)
        low - low value of range (float)
        high - high value of range (float > low)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        matrix - a 2D list of random numbers (2D list of float/int)
    -------------------------------------------------------
    """

    matrix = []

    if value_type == "float":

        for i in range(rows):
            row = []
            for j in range(cols):
                row.append(random.uniform(low, high))
            matrix.append(row)
    elif value_type == "int":
        for i in range(rows):
            row = []
            for j in range(cols):
                row.append(random.randint(low, high))
            matrix.append(row)

    return matrix

# task 3


def print_matrix_num(matrix, value_type):
    """
    -------------------------------------------------------
    Prints the contents of a 2D list in a formatted table.
    Prints float values with 2 decimal points and prints row and
    column headings.
    Use: print_matrix_num(matrix, 'float')
    Use: print_matrix_num(matrix, 'int')
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of values (2D list)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        None.
    -------------------------------------------------------
    """

    print(f" ", end="")
    for w in range(len(matrix[0])):
        print(f"{w:6d}", end="")

    print()
    for i in range(len(matrix)):
        print(f"{i}", end='')
        for j in range(len(matrix[0])):

            if value_type == "int":
                print(f" {matrix[i][j]:5d}", end="")
            if value_type == "float":
                print(f" {matrix[i][j]:5.2f}", end="")
        if i != len(matrix)-1:
            print()

    return


# task 6
def matrix_stats(matrix):
    """
    -------------------------------------------------------
    Returns statistics on a 2D list.
        Use: smallest, largest, total, average = matrix_stats(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of numbers (2D list of float/int)
    Returns:
        smallest - the smallest number in matrix (float/int)
        largest - the largest number in matrix (float/int)
        total - the total of the numbers in matrix (float/int)
        average - the average of numbers in matrix (float/int)
    -------------------------------------------------------
    """
    if len(matrix) > 0:
        small = matrix[0][0]
        large = matrix[0][0]

    total = 0
    count = 0

    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            if small > matrix[i][j]:
                small = matrix[i][j]
            if large < matrix[i][j]:
                large = matrix[i][j]
            total = total + matrix[i][j]
            count = count + 1

    average = total / count
    smallest = small
    largest = large

    return smallest, largest, total, average

# task 09


def count_frequency(matrix, char):
    """
    -------------------------------------------------------
    Count the number of appearances of the given character char
    in matrix.
    Use: count = count_frequency(matrix, char)
    -------------------------------------------------------
    Parameters:
        matrix - the matrix to search in it (2D list of str)
        char - character to search for it (str, len = 1)
    Returns:
        count - the number of appearances of char in the matrix (int)
    -------------------------------------------------------
    """
    count = 0
    for i in matrix:
        for j in i:
            if j == char:
                count = count + 1
    return count

# task 14


def matrix_transpose(matrix):
    """
    -------------------------------------------------------
    Transpose the contents of matrix. (Swap the rows and columns.)
    Use: transposed = matrix_transpose(matrix):
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list (2D list of *)
    Returns:
        transposed - the transposed matrix (2D list of *)
    ------------------------------------------------------
    """
    transposed = []

    rows = len(matrix)
    cols = len(matrix[0]) if matrix else 0

    # Initialize the transposed matrix
    transposed = [[0] * rows for _ in range(cols)]

    # Populate the transposed matrix
    for i in range(rows):
        for j in range(cols):
            transposed[j][i] = matrix[i][j]

    return transposed
