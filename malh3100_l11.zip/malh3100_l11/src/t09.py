"""
-------------------------------------------------------
Lab 11 task 9
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
from functions import count_frequency

count = count_frequency(
    [['g', 'h', 'a', 'd'], ['o', 't', 'n', 'd'], ['w', 'j', 't', 'c']], 'd')
print(count)
