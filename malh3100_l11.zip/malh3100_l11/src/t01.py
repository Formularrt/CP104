"""
-------------------------------------------------------
Lab 11 task 1
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-30"
-------------------------------------------------------
"""

from functions import generate_matrix_num
rows = int(input("# of rows: "))
cols = int(input("# of columns : "))
low = int(input("Minimum value for range: "))
high = int(input("Maximum value for range: "))
type_v = str(input("Int or float values: "))
result = generate_matrix_num(rows, cols, low, high, type_v)

print(result)
