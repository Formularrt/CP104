"""
-------------------------------------------------------
Lab 11 task 6
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
from functions import matrix_stats

small, large, total, average = matrix_stats(
    [[2, 10, -1, 1-5], [0, -21, -3, -9], [-10, -10, 9, -11]])

print(f"({small}, {large}, {total}, {average})")
