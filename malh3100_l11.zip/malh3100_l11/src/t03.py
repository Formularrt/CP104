"""
-------------------------------------------------------
Lab 11 task 3
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
from functions import generate_matrix_num, print_matrix_num

rows = int(input("# of rows: "))
cols = int(input("# of columns : "))
low = int(input("Minimum value for range: "))
high = int(input("Maximum value for range: "))
type_v = str(input("Int or float values: "))

matrix = generate_matrix_num(rows, cols, low, high, type_v)

print_matrix_num(matrix, type_v)
