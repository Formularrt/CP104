from functions import total_wins

result = total_wins()
print(result)
