from functions import detect_prime

print(detect_prime(131))
