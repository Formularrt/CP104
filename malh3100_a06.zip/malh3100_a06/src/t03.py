from functions import interest_table

print("Test 1: interest_table(750, 8.5, 200)")
interest_table(750, 8.5, 200)
