from functions import factor_summation

# Test cases
print(factor_summation(9)) 
