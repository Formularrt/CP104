from functions import count_of_digits

# Test cases
print(count_of_digits(-1024))
