"""
-------------------------------------------------------
Functions Library
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""

# task 1


def total_wins():
    """
    Counts the total number of times the string "gold" appears as input and returns a tuple with the count of "purple" and "gold" respectively.
    Uses a while loop to continuously prompt the user for input until an empty string is entered.
    """

    purple_count = 0
    gold_count = 0

    while True:
        team = input("Enter the winning team: ")

        if team == "":
            break

        if team.lower() == "purple":
            purple_count += 1
        elif team.lower() == "gold":
            gold_count += 1

    return purple_count, gold_count


# task 2


def detect_prime(number):
    """
    -------------------------------------------------------
    Determines if number is a prime number.
    Use: prime = detect_prime(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        prime - True if number is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    i = 2
    while i < number:
        if number % i == 0:
            prime = False
            break
        else:
            i = i + 1
            prime = True
    return prime

# task 3


def interest_table(principal_amount, interest_rate, payment):
    """
    Prints a table of monthly interest and payments on a loan.

    Parameters:
        principal_amount (float): original value of a loan (must be greater than 0)
        interest_rate (float): yearly interest rate as a percentage (must be greater than 0)
        payment (float): the monthly payment (must be greater than 0)

    Returns:
        None
    """
    month = 1

    # Print loan details
    print(f"Interest rate:  ${principal_amount:.2f}")
    print(f"Interest rate: {interest_rate:.2%}")
    print(f"Monthly payment: ${payment:.2f}")
    print("----------------------------------")
    print("Month Interest   Payment   Balance")
    print("----------------------------------")

    while principal_amount > 0:
        monthly_int = (interest_rate/12)/100*principal_amount

        if principal_amount - payment < 0:
            payment = principal_amount+monthly_int

        principal_payment = payment - monthly_int

        if principal_amount - principal_payment < 0:
            principal_payment = principal_amount

        principal_amount -= principal_payment

        print(
            f"{month:5d} {monthly_int:8.2f} {payment:9.2f} {principal_amount:9.2f}")

        month += 1
    return None

# task 4


def count_of_digits(number):
    """
    Counts the number of digits in an integer.

    Parameters:
        number (int): an integer

    Returns:
        digits (int): the number of digits in number
    """
    if number == 0:
        return 1

    count = 0
    number = abs(number)

    while number != 0:
        number //= 10
        count += 1

    return count

# task 5


def factor_summation(number):
    """
    Determines the sum of factors of an integer not including
    the integer itself.

    Parameters:
        number - a positive integer (int >= 1)
    Returns:
        total - the total of number's factors (int)
    """
    if number < 1:
        raise ValueError("Input must be a positive integer (int >= 1)")

    total = 0
    divisor = 1

    while divisor <= number // 2:
        if number % divisor == 0:
            total += divisor
        divisor += 1

    return total
