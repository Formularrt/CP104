"""
-------------------------------------------------------
Assignment 07 Task 01
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
from functions import list_factors

print(list_factors(9))
