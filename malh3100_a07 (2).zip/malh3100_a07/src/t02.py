"""
-------------------------------------------------------
Assignment 07 Task 02
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
from functions import list_positives

print(list_positives())
