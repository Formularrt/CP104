"""
-------------------------------------------------------
Assignment 07 Task 03
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
from functions import get_indexes

print(get_indexes([5, 1, 8, 9, 5, 2, 5, 3], 5))
