"""
-------------------------------------------------------
Assignment 07 Task 04
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
from functions import list_subtract

print(list_subtract([5, 5, 4, 5], [5]))
