"""
-------------------------------------------------------
Assignment 07 Task 05
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
from functions import verify_sorted

print(verify_sorted([1, 2, 3]))
