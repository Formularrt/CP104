"""
-------------------------------------------------------
Lab 8 task 5
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-08"
-------------------------------------------------------
"""
from functions import get_lotto_numbers

lotto_numbers = get_lotto_numbers(n=6, low=1, high=49)
print(lotto_numbers)
