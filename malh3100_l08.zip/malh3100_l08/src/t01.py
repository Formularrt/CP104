"""
-------------------------------------------------------
Lab 8 task 1
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-08"
-------------------------------------------------------
"""
from functions import get_weekday_name


for i in range(0, 7):
    num = int(input("Number between 1 - 7: "))
    weekday = get_weekday_name(num)
    print(weekday)
