"""
-------------------------------------------------------
Lab 8 task 8
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-08"
-------------------------------------------------------
"""
from functions import linear_search

values = [94, 96, -22, -79, -28, -26, -50, 71, 24, -32]
value = -22

index = linear_search(values, value)

if index != -1:
    print(f"The value {value} was found at index {index}.")
else:
    print(f"The value {value} was not found in the list.")
