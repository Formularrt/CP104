"""
-------------------------------------------------------
Lab 8 task 14
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      353690316
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-08"
-------------------------------------------------------
"""
from functions import intersection


source1 = [10, 3, 10, 3, 1]
source2 = [8, 2, 7, 3, 6, 10, 32, 99]

result = intersection(source1, source2)
print(result)
