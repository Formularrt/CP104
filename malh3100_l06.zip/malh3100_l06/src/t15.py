"""
-------------------------------------------------------
Lab 6, Task 15 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""

from functions import statistics

results = statistics(5)
print(
    f"( {results[0]:.2f}, {results[1]:.2f}, {results[2]:.2f}, {results[3]:.2f})")
