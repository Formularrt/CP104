"""
-------------------------------------------------------
Lab 6, Task 2 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""
from functions import sum_odd


user_input = int(input("Enter a number:"))


result = sum_odd(user_input)

# Print the result
print(f"Result for sum_odd({user_input}): {result}")
