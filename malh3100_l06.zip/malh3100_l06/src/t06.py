"""
-------------------------------------------------------
Lab 6, Task 6 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-27"
-------------------------------------------------------
"""

from functions import draw_triangle

height = int(input("What is the height?: "))
char = input("What charaters do you want the traingle to be made of?: ")

print(draw_triangle(height, char))
