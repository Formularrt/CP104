"""
-------------------------------------------------------
Assignment 09 Task 03
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
from functions import file_statistics

file_handle = open("addresses.txt", "r", encoding="utf-8")

ucount, lcount, dcount, wcount, rcount = file_statistics(file_handle)

file_handle.close()
print(ucount, lcount, dcount, wcount, rcount)
