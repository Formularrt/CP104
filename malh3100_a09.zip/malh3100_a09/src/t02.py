"""
-------------------------------------------------------
Assignment 09 Task 02
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
from functions import read_integers

file_handle = open("numbers.txt", "r", encoding="utf-8")

number_list = read_integers(file_handle)

file_handle.close()
print(number_list)
