"""
-------------------------------------------------------
Assignment 09 Task 04
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
from functions import line_numbering

fh_read = open("wilde.txt", "r", encoding="utf-8")
fh_write = open("output.txt", "w", encoding="utf-8")

line_numbering(fh_read, fh_write)

fh_read.close()
