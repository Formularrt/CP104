"""
-------------------------------------------------------
Assignment 09 Task 05
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
from functions import student_stats
filename = "students.txt"
fh_1 = open(filename, "r+")
l_id, h_id, avg = student_stats(fh_1)
fh_1.close()
print(l_id, h_id, avg)
