"""
-------------------------------------------------------
Assignment 09 Task 01
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
from functions import file_top

file_handle = open("students.txt", "r", encoding="utf-8")

file_top(file_handle, 5)

file_handle.close()
