"""
-------------------------------------------------------
Assignment 03 Task 01
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
from functions import footage_to_acres

square_feet = 100000
acres = footage_to_acres(square_feet)

print(f"Square footage: {square_feet}")
print(f"footage_to_acres({square_feet:.1f}) -> {acres}")
