"""
-------------------------------------------------------
Assignment 03 Task 04
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
from functions import fraction_multiplier

number1 = 1
denom1 = 2
number2 = 3
denom2 = 4

num, denom, product = fraction_multiplier(number1, denom1, number2, denom2)

print(f"Numerator 1: {number1}")
print(f"Denominator 1: {denom1}")
print(f"Numerator 2: {number2}")
print(f"Denominator 2: {denom2}")

print(
    f"fraction_multiplier({number1}, {denom1}, {number2}, {denom2}) -> ({num}, {denom}, {product})")
