"""
-------------------------------------------------------
Assignment 03 Task 05
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169017208
Email:   pama7208@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
from functions import math_quiz()

user_answer = int(input("Enter your answer: "))

print()
print(f"Your answer:     {user_answer:3d}")
print(f"Expected answer: {total:3d}")
