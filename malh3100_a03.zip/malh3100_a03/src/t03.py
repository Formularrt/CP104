"""
-------------------------------------------------------
Assignment 03 Task 03
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
from functions import date_extraction

date_number_format = 10251962

year, day, month = date_extraction(date_number_format)

print(f"Enter a date in the format MMDDYYYY: {date_number_format}")
print(f"date_extraction({date_number_format}) -> {year}, {day}, {month}")
