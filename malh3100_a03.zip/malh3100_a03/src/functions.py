"""
-------------------------------------------------------
Functions Library
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# task 01


def footage_to_acres(square_feet):
    """
    -------------------------------------------------------
    Converts square footage to acres.
    Use: acres = footage_to_acres(square_feet)
    -------------------------------------------------------
    Parameters:
        square_feet - area in square feet (float >= 0)
    Returns:
        acres - square_footage in acres (float)
    ------------------------------------------------------
    """
    acres = square_feet / 43560

    return acres


# task 02
def lawn_mowing(width, length, speed):
    """
    -------------------------------------------------------
    Determines how long it takes to mow a rectangular lawn.
    Use: time = lawn_mowing(width, length, speed)
    -------------------------------------------------------
    Parameters:
        width - width of a lawn in metres (float > 0)
        length - length of a lawn in metres (float > 0)
        speed - square metres cut per minute (float > 0)
    Returns:
        time_minutes - time required to mow the lawn (float)
    ------------------------------------------------------
    """
    time_minutes = (width * length) / speed

    return time_minutes


# task 03
def date_extraction(date_number_format):
    """
    -------------------------------------------------------
    Extracts the year, month, and day from a date number in the format MMDDYYYY.
    Use: year, month, day = date_extraction(date_number_format)
    -------------------------------------------------------
    Parameters:
        date_number_format - a date number in the format MMDDYYYY (int > 0)
    Returns:
        year - year portion of date_number (int)
        month - month portion of date_number (int)
        day - day portion of date_number (int)
    ------------------------------------------------------
    """

    day = date_number_format // 1000000
    month = (date_number_format % 1000000) // 10000
    year = date_number_format % 10000

    return year, day, month


# task 04
def fraction_multiplier(number1, denom1, number2, denom2):
    """
    -------------------------------------------------------
    Multiplies two fractions together and returns the results
    Use: num, denom, product = fraction_multiplier(number1, denom1, number2, denom2)
    -------------------------------------------------------
    Parameters:
        number1 - numerator of the first fraction (int)
        denom1 - denominator of the first fraction (int)
        number2 - numerator of the second fraction (int)
        denom2 - denominator of the second fraction (int)
    Returns:
        num - numerator of the resulting fraction (int)
        denom - denominator of the resulting fraction  (int)
        product - numerator divided by denominator (float)
    ------------------------------------------------------
    """
    num = number1 * number2
    denom = denom1 * denom2
    product = num / denom

    return num, denom, product


# task 05
def math_quiz():
    num1 = randint(0, MAX_VALUE)
    num2 = randint(0, MAX_VALUE)

    total = num1 + num2

    print(f'  {num1:2d}')
    print(f'+ {num2:2d}')
    print()

    return
