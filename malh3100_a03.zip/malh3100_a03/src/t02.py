"""
-------------------------------------------------------
Assignment 03 Task 02
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
from functions import lawn_mowing

width = 20
length = 50
speed = 4

print(f"Width (m): {width}")
print(f"Length (m): {length}")
print(f"Speed (m^2/minute): {speed}")

time = lawn_mowing(width, length, speed)
print(f"lawn_mowing({width:.1f}, {length:.1f}, {speed:.1f}) -> {time}")
