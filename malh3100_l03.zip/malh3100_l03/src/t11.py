"""
-------------------------------------------------------
Lab 3, Task 11 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""
left = "left"
middle = "middle"
right = "right"

print(f"{left:-<20s}")
print(f"{middle:-^20s}")
print(f"{right:->20s}")
