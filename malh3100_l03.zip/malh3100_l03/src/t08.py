"""
-------------------------------------------------------
Lab 3, Task 8 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""
dirt = float(input("Please enter amount of dirt (m^3):"))
gravel = float(input("Please enter the amount of gravel(m^3):"))
sand = float(input("Please enter the amount of sand(m^3):"))
total = dirt + gravel + sand
print(f"""
Material   Cubic
Dirt       {dirt:5.1f}
Gravel     {gravel:5.1f}
Sand       {sand:5.1f}
Total      {total:5.1f}
""")
