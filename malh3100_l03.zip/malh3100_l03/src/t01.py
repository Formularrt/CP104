"""
-------------------------------------------------------
Lab 3, Task 1 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-09-27"
-------------------------------------------------------
"""
print("""
'I'm a Little Astronaut' by Jean Warren

I'm a little astronaut
    Flying to the moon.
        My rocket is ready,
        We blast off soon.
I climb aboard
    And close the hatch.
        5-4-3-2-1, off we blast!
""")
