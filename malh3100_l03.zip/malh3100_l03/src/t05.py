"""
-------------------------------------------------------
Lab 3, Task 5 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""
minimum = int(input("Enter minimum:"))
maximum = int(input("Enter maximum:"))
answer = maximum - minimum

print()

print(f"The difference between {maximum:d} and {minimum:d} is {answer:d}")
38
