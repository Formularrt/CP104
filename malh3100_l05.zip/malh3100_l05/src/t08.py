"""
-------------------------------------------------------
Lab 5, Task 8 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-19"
-------------------------------------------------------
"""

from functions import roman_numeral

# Test the roman_numeral function
n = int(input("Enter a number 1-10:"))
numeral = roman_numeral(n)

print(numeral)
