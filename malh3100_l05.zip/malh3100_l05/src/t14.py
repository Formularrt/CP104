"""
-------------------------------------------------------
Lab 5, Task 14 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""
from functions import ticket

# Call the ticket function to calculate the price
price = ticket()

print(f"Ticket Price: ${price:.2f}")
