"""
-------------------------------------------------------
Lab 5, Task 5 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-17"
-------------------------------------------------------
"""

from functions import is_leap

year = int(input("Enter year:"))

result = is_leap(year)

print(f"is_leap({year})")
print(result)
