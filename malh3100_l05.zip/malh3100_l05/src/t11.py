"""
-------------------------------------------------------
Lab 5, Task 11 
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""
from functions import quadrant

# Test the quadrant function with various coordinates
x = int(input("Number on x-axis: "))
y = int(input("Number on y-axis: "))


location = quadrant(x, y)
print(f"Coordinates ({x}, {y}) are in {location}.")
