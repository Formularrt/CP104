"""
-------------------------------------------------------
Assignment 1, Task 4
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""

cost = float(input("Cost of one dosa:"))
# cost is price per dosa
dosa = int(input("Number of dosa:"))

price = cost*dosa

print(f"The cost of {dosa} dosas: {price}")
