"""
-------------------------------------------------------
Assignment 1, Task 1
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""

age = int(input("What is your age? "))
band = input("What is your favourite band? ")

print(f"I am {age} years old and {band} is my favourite band.")
