"""
-------------------------------------------------------
Assignment 1, Task 3
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
m = float(input("Length in miles:"))
#m = miles
km = m*1.61

print(f"Length in km: {km}")
