"""
-------------------------------------------------------
Assignment 1, Task 5
-------------------------------------------------------
Author: Aikam Malhotra
ID: 169053100
Email: malh3100@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
p = float(input("Principal:"))
r = float(input("Interest (%):"))
t = int(input("Number of years:"))
n = int(input("Number of times interest compounded per year:"))

r = r/100

answer = p*(1+(r/n))**(n*t)

print(f"Balance: {answer}")
