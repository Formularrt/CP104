"""
-------------------------------------------------------
Functions Library
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# import


def day_name(day_num):
    """
    -------------------------------------------------------
    Returns the name of a day of the week given an integer day number.
    Day 1 is "Sunday", day 7 is "Saturday".
    Returns "Error" if the number is not valid.
    Use: day = day_name(day_num)
    -------------------------------------------------------
    Parameters:
        day_num - day number (1 <= int <= 7)
    Returns:
        day - name of a day of the week (str)
    ------------------------------------------------------
    """
    day = ' '
    if day_num == 1:
        day = 'Sunday'
    elif day_num == 2:
        day = 'Monday'
    elif day_num == 3:
        day = 'Tuesday'
    elif day_num == 4:
        day = 'Wednesday'
    elif day_num == 5:
        day = 'Thursday'
    elif day_num == 6:
        day = 'Friday'
    elif day_num == 7:
        day = 'Saturday'
    else:
        day = 'Error'
    return day


def pollution_ranking(air_quality_index):
    """
    -------------------------------------------------------
    Returns the pollution level given an AQI (Air Quality Index):
        "Good" - 0 to 50 AQI
        "Moderate" - 51 - 100 AQI
        "Unhealthy for Sensitive Groups" - 101 - 150 AQI
        "Unhealthy" - 151 - 200 AQI
        "Very Unhealthy" - 201 - 300 AQI
        "Hazardous" - 300+ AQI
    Returns "Error" if air_quality_index is negative.
    Use: pollution = pollution_ranking(air_quality_index)
    -------------------------------------------------------
    Parameters:
        air_quality_index - Air Quality Index (int)
    Returns:
        pollution - name of pollution level (str)
    ------------------------------------------------------
    """

    if air_quality_index < 0:
        level = 'Error'
    elif air_quality_index <= 50:
        level = 'Good'
    elif air_quality_index <= 100:
        level = 'Moderate'
    elif air_quality_index <= 150:
        level = 'Unhealthy for Sensitive Groups'
    elif air_quality_index <= 200:
        level = 'Unhealthy'
    elif air_quality_index <= 300:
        level = 'Very Unhealthy'
    else:
        level = 'Hazardous'
    return level


def largest_average(val1, val2, val3):
    """
    -------------------------------------------------------
    Returns the average of the two largest values of
    val1, val2, and val3.
    Use: average = largest_average(val1, val2, val3)
    -------------------------------------------------------
    Parameters:
        val1 - a number (float)
        val2 - a number (float)
        val3 - a number (float)
    Returns:
        average - the average of the two largest values of
            val1, val2, and val3 (float)
    ------------------------------------------------------
    """

    if val1 > val3 and val2 > val3:
        product = (val1 + val2)/2
    elif val1 > val2:
        product = (val1 + val3)/2
    else:
        product = (val3 + val2)/2

    return product


def colour_combine(rgb_colour1, rgb_colour2):
    """
    -------------------------------------------------------
    Determines the secondary colour from mixing two primary
    RGB (Red, Green, Blue) colours. The order of the colours
    is *not* significant.
    Returns "Error" if any of the colour parameter(s) are invalid.
        "red" + "blue": "fuchsia"
        "red" + "green": "yellow"
        "green" + "blue": "aqua"
        "red" + "red": "red"
        "blue" + "blue": "blue"
        "green" + "green": "green"
    Use: colour = rgb_mix(rgb_colour1, rgb_colour2 )
    -------------------------------------------------------
    Parameters:
        rgb_colour1 - a primary RGB colour (str)
        rgb_colour2 - a primary RGB colour (str)
    Returns:
        colour - a secondary RGB colour (str)
    -------------------------------------------------------
    """
    if rgb_colour1 == 'red' and rgb_colour2 == 'blue' or rgb_colour1 == 'blue' and rgb_colour2 == 'red':
        colour = 'fuchsia'

    elif rgb_colour1 == 'green' and rgb_colour2 == 'blue' or rgb_colour1 == 'blue' and rgb_colour2 == 'green':
        colour = 'aqua'

    elif rgb_colour1 == 'red' and rgb_colour2 == 'green' or rgb_colour1 == 'green' and rgb_colour2 == 'red':
        colour = 'yellow'

    elif rgb_colour1 == 'red' and rgb_colour2 == 'red':
        colour = 'red'

    elif rgb_colour1 == 'blue' and rgb_colour2 == 'blue':
        colour = 'blue'

    elif rgb_colour1 == 'green' and rgb_colour2 == 'green':
        colour = 'green'
    else:
        colour = 'Error'
    return colour


def hoo_rah(number):
    """
    -------------------------------------------------------
    Determines if a number can be evenly divided by 3, 7, or both evenly

    Use: answer = yee_haw(number) 
    -------------------------------------------------------
    Parameters:
        number - the value that is going to be divided (int > 0 ) 
    Returns:
        answer-  Tells if it can be divided or tells it is not message  (str)
    -------------------------------------------------------
    """

    if number % 3 == 0 and number % 7 == 0:
        answer = 'Hoo Rah'
    elif number % 7 == 0:
        answer = 'Rah'
    elif number % 2 == 0:
        answer = 'Hoo'
    else:
        answer = 'Zip'
    return answer
