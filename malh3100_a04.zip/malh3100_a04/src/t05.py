from functions import hoo_rah

answer = hoo_rah(0)

print(answer)
