from functions import day_name

day = day_name(7)
print(day)
