from functions import colour_combine

colour1 = str(input("Enter a colour(in lower case letters)"))
colour2 = str(input("Enter a colour(in lower case letters)"))
colour1 = colour1.lower()
colour2 = colour2.lower()

colour = colour_combine(colour1, colour2)

print(colour)
