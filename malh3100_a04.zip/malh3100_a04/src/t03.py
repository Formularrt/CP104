from functions import largest_average

average = largest_average(7.4, 90.6, 30.778)

print(average)
