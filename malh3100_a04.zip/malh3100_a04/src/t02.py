from functions import pollution_ranking

number = float(input("Input the number here:"))

level = pollution_ranking(number)

print(level)
