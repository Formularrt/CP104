# task 03
from functions import arrow_up

# Test the function with different sets of parameters
arrow_up(4)
