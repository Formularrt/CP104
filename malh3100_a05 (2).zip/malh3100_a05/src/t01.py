
from functions import calc_factorial

product = calc_factorial(5)

print(product)
