
from functions import range_addition

total = range_addition(100, 1, 100)

print(total)
