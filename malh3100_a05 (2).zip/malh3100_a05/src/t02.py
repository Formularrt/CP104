
from functions import calories_treadmill

# Test the function with different sets of parameters
calories_treadmill(4.1, 20)
