"""
-------------------------------------------------------
Functions Library
-------------------------------------------------------
Author:  Aikam Malhotra
ID:      169053100
Email:   malh3100@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# task 01


def calc_factorial(number):
    """
    -------------------------------------------------------
    Calculates and returns the factorial of number.
    Use: product = calc_factorial(number)
    -------------------------------------------------------
    Parameters:
        number - number to factorial (int > 0)
    Returns:
        product - number! (int)
    ------------------------------------------------------
    """

    product = 1
    for i in range(1, number + 1):
        product *= i
    return product

# task 02


def calories_treadmill(per_min, minutes):
    if minutes == 0:
        print("You did not burn anything")
    for i in range(5, minutes + 1, 5):
        calories_burned = i * per_min
        print(f"{i:2} {calories_burned:.1f}")

# task 03


def arrow_up(rows):
    print(" " * (rows-1) + "#")
    for x in range(1, rows):
        arrow = (" "*(rows-x-1) + "#" + (" "*(2*x-1)+"#"))
        print(arrow)
    return None

# task 04


def multiplication_table(start, stop):
    """
    -------------------------------------------------------
    Prints a multiplication table for values from start to stop.
    Use: multiplication_table(start, stop)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        stop - the range stop value (int)
    Returns:
        None
    ------------------------------------------------------
    """
    space = "   "
    for g in range(start, stop+1):
        if g == start:
            print(f"{space}{g:>4}", end=" ")
        else:
            print(f"{g:>4}", end=" ")
    print()
    print(space + "-----" * stop)

    for i in range(start, stop+1):
        print(f"{i:d}|", end=" ")

        for j in range(start, stop + 1):

            print(f"{i*j:4d}", end=" ")
        print()

# task 5


def range_addition(start, increment, count):
    """
    -------------------------------------------------------
    Uses a for loop to sum values from start by increment.
    Use: total = range_addition(start, increment, count)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """
    sum = 0
    end = (increment * count) + start
    for x in range(start, end, increment):
        sum += x
    return(sum)
    return
