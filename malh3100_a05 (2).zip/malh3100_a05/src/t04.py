
# Imports
from functions import multiplication_table

multiplication_table(1, 3)
